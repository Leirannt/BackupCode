/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project_tel.u;

/**
 *
 * @author oyest
 */
public class Project_TelU {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
